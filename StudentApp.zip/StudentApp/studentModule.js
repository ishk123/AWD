var sApp = angular.module('studApp',[]);
sApp.controller('studCtrl',function($scope){
    //code
    $scope.studInfo= [
        {sID:'22MSIT002',sName:'Nency',course:'M.Sc.(IT)',age:23,awd:87,sqat:77},
        {sID:'22MSIT015',sName:'Bhavya',course:'M.Sc.(IT)',age:23,awd:66,sqat:87},
        {sID:'22MSIT036',sName:'Pratham',course:'M.Sc.(IT)',age:23,awd:68,sqat:56},
        {sID:'22MSIT039',sName:'Nehali',course:'M.Sc.(IT)',age:23,awd:57,sqat:60},
        {sID:'22MSIT017',sName:'Cyber',course:'M.Sc.(IT)',age:23,awd:64,sqat:67},
        {sID:'22MSIT016',sName:'Maharshi',course:'M.Sc.(IT)',age:23,awd:87,sqat:77}
    ]
    //result function
    
    $scope.dispResult = function(i){
        //function code
        $scope.sub1 = i.awd
        $scope.sub2 = i.sqat

    }
   
})